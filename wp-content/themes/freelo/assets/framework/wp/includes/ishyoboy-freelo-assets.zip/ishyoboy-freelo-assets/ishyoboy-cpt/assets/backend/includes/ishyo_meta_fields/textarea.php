<textarea name="<?php echo esc_attr( $id ); ?>" id="<?php echo esc_attr( $id ); ?>" rows="5" cols="50" class="regular-text"><?php echo '' . $value?></textarea>
