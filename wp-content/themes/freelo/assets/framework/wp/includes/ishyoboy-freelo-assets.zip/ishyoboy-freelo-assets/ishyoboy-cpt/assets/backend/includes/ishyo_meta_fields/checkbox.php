<input type="checkbox" name="<?php echo esc_attr($id); ?>" id="<?php echo esc_attr($id); ?>" <?php checked($value, 'true')?> value="true" />
