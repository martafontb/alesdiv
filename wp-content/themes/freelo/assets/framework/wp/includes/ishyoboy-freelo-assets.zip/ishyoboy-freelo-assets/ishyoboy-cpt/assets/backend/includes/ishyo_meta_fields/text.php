<input type="text" name="<?php echo esc_attr( $id ); ?>" id="<?php echo esc_attr($id); ?>" value="<?php echo esc_attr($value); ?>" class="regular-text" />
