<input type="button" class="button-secondary upload-<?php the_ID(); ?>" name="<?php echo esc_attr($id); ?>" id="ishyoboy_images_upload" value="<?php echo esc_attr($value); ?>" />
